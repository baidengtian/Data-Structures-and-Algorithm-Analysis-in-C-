#pragma once
/*
 * @Author: your name
 * @Date: 2020-02-19 19:50:19
 * @LastEditTime: 2020-02-19 19:50:20
 * @LastEditors: Please set LastEditors
 * @Description: �׳��쳣
 * @FilePath: \LeftistHeap\Inc\dsexceptions.h
 */

class UnderflowException { };
class IllegalArgumentException { };
class ArrayIndexOutOfBoundsException { };
class IteratorOutOfBoundsException { };
class IteratorMismatchException { };
class IteratorUninitializedException { };
class CycleFoundException { };

