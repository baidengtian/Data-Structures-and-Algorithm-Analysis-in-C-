/*
 * @Author: your name
 * @Date: 2020-02-11 16:31:25
 * @LastEditTime: 2020-02-21 17:04:06
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \BinomialQueue\Src\main.cpp
 */



#include <iostream>
#include <string>
#include "BinomialQueue.h"
#include <vector>

using namespace std;


int main()

{

    BinomialQueue<int> bq;
    
    bq.insert( 1 );
    bq.insert( 2 );
    bq.insert( 4 );
    bq.insert( 5 );
    BinomialQueue<int> bq2( bq );
    BinomialQueue<int> bq3;
    bq3 = bq;
    bool flag = bq.isEmpty( );
    int min_val = 0;
    bq.deleteMin( min_val );
    bq.makeEmpty( );
    flag = bq.isEmpty( );
    return 0;
}


