/*
 * @Author: your name
 * @Date: 2020-02-15 16:08:15
 * @LastEditTime: 2020-02-19 21:58:25
 * @LastEditors: Please set LastEditors
 * @Description: ��ʽ��
 * @FilePath: \LeftistHeap\Inc\LeftistHeap.h
 */

#ifndef __SKEWHEAD_H
#define __SKEWHEAD_H


#include <vector>
#include <iostream>
#include "dsexceptions.h"

template < typename Comparable >
class SkewHeap
{
public:
    SkewHeap( ) : root{ nullptr }
    {

    }
    SkewHeap( const SkewHeap & rhs ): root( nullptr )
    {
        this->root = clone( rhs.root );
    }
    ~SkewHeap( )
    {
        makeEmpty( );
    }
    // ���
    SkewHeap & operator = ( const SkewHeap & rhs )
    {
        SkewHeap copy = rhs;
        std::swap( *this, copy );
        return *this;
    }
    // �ƶ�
    SkewHeap & operator = ( SkewHeap && rhs )
    {
        std::swap( root, rhs.root );
        
        return *this;
    }

    // �ж���ʽ���Ƿ�Ϊ��
    bool isEmpty( ) const
    {
        return root == nullptr;
    }
    // Ѱ����Сֵ
    const Comparable & findMin( )   const
    {
        if( isEmpty( ) )
            throw UnderflowException{ };
        return root->element;
    }
    // ����ڵ� x
    void insert( const Comparable & x )
    {
        root = merge( new SkewNode{ x }, root );
    }
    // ɾ����С��
    void deleteMin( )
    {
        if( isEmpty( ) )
           throw UnderflowException{ };
        
        SkewNode* oldRoot = root;
        root = merge( root->left, root->right );
        delete oldRoot;
    }
    // ɾ����Сֵ
    void deleteMin( Comparable & minItem )
    {
        minItem = findMin( );
        deleteMin( );
    }
    void makeEmpty( )
    {
        reclaimMemory( root );
        root = nullptr;
    }
    // �� rhs �ϲ������ȶ���
    void merge( SkewHeap & rhs )
    {
        if( this == &rhs )                      // rhs ���벻ͬ�� this
            return;
        root = merge( root, rhs.root );
        rhs.root = nullptr;
    }

    void print( )   const
    {
        if( root != nullptr )
            print( root );
    }
private:
    struct SkewNode
    {
        Comparable element;
        SkewNode* left;
        SkewNode* right;
        SkewNode( const Comparable & e, SkewNode* lt = nullptr, 
                    SkewNode* rt = nullptr)
        : element{ e }, left{ lt }, right{ rt }
        {

        }

    };

    SkewNode* root;          // ���ڵ�
    // �ϲ�������
    SkewNode* merge( SkewNode* h1, SkewNode* h2 )
    {
        if( h1 == nullptr )
            return h2;
        if( h2 == nullptr )
            return h1;
        if( h1->element < h2->element )
            return merge1( h1, h2 );
        else
            return merge1( h2, h1 );
    }
    // �ϲ�������ʽ�� h1 < h2
    SkewNode* merge1( SkewNode* h1, SkewNode* h2 )
    {
        if( h1->left == nullptr )  
            h1->left = h2;
        else
        {
            // �ݹ�ϲ����ڵ�С������������ڵ�����
            h1->right = merge( h1->right, h2 );        
            // ����������·����С������������·����ʱ������������
            // if( h1->left->npl < h1->right->npl )
            swapChildren( h1 );
            // ���ڵ����·���� = ��������·���� + 1 
            // h1->npl = h1->right->npl + 1; 
        }

        return h1;
    }
    // ����һ���ڵ�����Ҷ���
    void swapChildren( SkewNode* t )
    {
        SkewNode* tempNode = t->left; 
        t->left = t->right;
        t->right = tempNode;
    }
    void reclaimMemory( SkewNode* t )
    {
        if( t != nullptr )
        {
            reclaimMemory( t->left );
            reclaimMemory( t->right );
            delete t;
        }
    }
    // ��¡�ڵ�
    SkewNode* clone( SkewNode* t )    const
    {
        if( t == nullptr )
            return nullptr;
        else
            return new SkewNode{ t->element, clone( t->left ), clone( t->right ), t->npl };
        
    }
    // ��ӡ
    void print( SkewNode* t , std::ostream & os = std::cout )   const
    {
        if( t != nullptr )
        {
            std::cout << t->element << std::endl;
            print( t->left, os );      
            print( t->right, os );
        }

    }
};





#endif