/*
 * @Author: your name
 * @Date: 2020-02-11 16:31:25
 * @LastEditTime: 2020-02-19 21:56:29
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \CuckooHash Table\Src\main.cpp
 */


#include <iostream>
#include <string>
#include "SkewHeap.h"
#include <vector>

using namespace std;


int main()

{

    int a[]= {10,40,24,30,36,20,12,16};
    int b[]= {17,13,11,15,19,21,23};
    SkewHeap<int> h1;
    SkewHeap<int> h2;
    for( auto x : a )
        h1.insert( x );
    for( auto x : b )
        h2.insert( x );
    
    h1.merge( h2 );
    h1.print( );
    // int i = 10;
    // int j = 20;
    // std::cout << "&i = " << &i << "         " << "&j = " << &j << std::endl;
    // swap( i, j );
    // std::cout << "&i = " << &i << "         " << "&j = " << &j << std::endl;
    // LeftistHeap<int> lh;
    // lh.insert( 1 );
    // lh.insert( 4 );
    // lh.insert( 8 );
    // lh.insert( 9 );
    // lh.insert( 7 );

    // LeftistHeap<int> lh2;
    // lh2.insert( 2 );
    // lh2.insert( 5 );
    // lh2.insert( 10 );
    // lh2.insert( 0 );
    // lh2.insert( 99 );

    // lh.merge( lh2 );
    
    // int val = lh.findMin( );
    // lh.deleteMin( );
    // lh.deleteMin( );
    // lh.makeEmpty( );
    
    // LeftistHeap<int> lh1;
    // lh1 = lh;
    return 0;
}


